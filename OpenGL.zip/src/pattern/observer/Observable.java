package pattern.observer;

public interface Observable {
	public void notificar();
}
