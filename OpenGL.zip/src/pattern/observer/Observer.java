package pattern.observer;

public interface Observer {
	public void atualizar();
}
