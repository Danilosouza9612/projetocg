package renderer;

import com.jogamp.opengl.GL2;

public interface DrawEvent {
	public void draw(GL2 gl);
}
